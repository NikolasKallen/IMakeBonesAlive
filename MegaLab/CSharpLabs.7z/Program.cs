﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace MegaLab
{
    class Program : Product
    {
        static void Main(string[] args)
        {
        }
    }
}
